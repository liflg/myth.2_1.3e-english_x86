/*
 * Copyright (c) 2004, 2009 Tobias Rautenkranz <tobias@rautenkranz.ch>
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <dlfcn.h>

/* Old meminfo emulating 256Mb */
static char meminfo_str[] = 
"root: total: used: free: shared: buffers: cached:\n"
"Mem: 268435456 0 268435456 0 0 0\n"
"Swap: 268435456 0 268435456\n";

FILE*
fopen(const char *filename, const char *mode)
{
	FILE* (*_fopen)(const char*,const char*) = dlsym(RTLD_NEXT, "fopen");

	if (!_fopen)
	{
		fprintf(stderr, "myth-meminfo: dlsym: %s\n", dlerror());
		return NULL;
	}
	
	if (strcmp(filename, "/proc/meminfo") == 0)
	{
		fprintf(stderr, "myth-meminfo: fixing /proc/meminfo\n");

		return fmemopen(meminfo_str, sizeof(meminfo_str), mode);
	}
	else
		return _fopen(filename, mode);
}
